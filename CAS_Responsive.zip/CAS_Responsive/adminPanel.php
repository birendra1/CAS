<!DOCTYPE html>
<html>
<head>
	<title>AdminPanel</title>
	 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style type="text/css">

</style>
  
</head>
<body>

  <nav>
  <button align="center" class="w3-xxlarge w3-padding" style="background: #cccdcc;width: 100% " id="heading" >Admin Panel</button>
</nav>

<!-- Top Nav Panel -->

<div class="w3-container">


  <div class="w3-bar " style="width: 103%;margin-left: -4.75%;position: fixed;margin-top: 45px">
  	
 
   
    <a href="addOfficer.php" class="w3-bar-item w3-button w3-mobile w3-gray"  style="width: 100%;height: 55px;margin-bottom: 8px;padding: 13px;font-size: 25px">Add Officer</a>

    <a href="viewComplaint.php" class="w3-bar-item w3-button w3-mobile w3-gray" style="width: 100%;height: 55px;margin-bottom: 8px;padding: 13px;font-size: 25px">View Complaints</a>
    <a href="viewOfficer.php" class="w3-bar-item w3-button w3-mobile w3-gray" style="width: 100%;height: 55px;margin-bottom: 8px;padding: 13px;font-size: 25px">View Officer</a>
    
      
      <a href="logout.php" class="w3-bar-item w3-button w3-mobile w3-red" style="width: 100%;height: 55px;margin-bottom: 8px;padding: 13px;font-size: 25px">Logout</a>
    </div>
</div>
</div>





</body>


</html>