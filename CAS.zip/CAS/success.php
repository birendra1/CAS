<!DOCTYPE html>
<html>
<head>
	<title>
	
	</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>
<script>

	alert("you are successfully registered"); 
</script>
<div style="margin-left: 45%;margin-top: 25%">
	<form action="userLogin.php">
<button class="w3-btn w3-xlarge w3-padding w3-blue">Click here to Login</button>
</form>
</div>
</body>
</html>